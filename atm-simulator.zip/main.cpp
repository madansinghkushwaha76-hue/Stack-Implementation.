#include <iostream>
using namespace std;

class ATM
{
private:
    int pin = 1234;
    int enteredPin;
    double balance = 10000.0;

public:
    void start()
    {
        cout << "========== ATM SIMULATOR ==========\n";
        cout << "Enter ATM PIN: ";
        cin >> enteredPin;

        if (enteredPin != pin)
        {
            cout << "Invalid PIN!" << endl;
            return;
        }

        int choice;
        double amount;

        do
        {
            cout << "\n========== MENU ==========\n";
            cout << "1. Check Balance\n";
            cout << "2. Deposit Money\n";
            cout << "3. Withdraw Money\n";
            cout << "4. Exit\n";
            cout << "Enter Choice: ";
            cin >> choice;

            switch (choice)
            {
                case 1:
                    cout << "Available Balance: Rs. " << balance << endl;
                    break;

                case 2:
                    cout << "Enter Deposit Amount: ";
                    cin >> amount;
                    balance += amount;
                    cout << "Deposit Successful!\n";
                    break;

                case 3:
                    cout << "Enter Withdraw Amount: ";
                    cin >> amount;

                    if (amount <= balance)
                    {
                        balance -= amount;
                        cout << "Please Collect Your Cash.\n";
                    }
                    else
                    {
                        cout << "Insufficient Balance!\n";
                    }
                    break;

                case 4:
                    cout << "Thank You for Using ATM.\n";
                    break;

                default:
                    cout << "Invalid Choice!\n";
            }

        } while (choice != 4);
    }
};

int main()
{
    ATM a;
    a.start();

    return 0;
}