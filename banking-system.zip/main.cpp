#include <iostream>
#include <string>
using namespace std;

class Bank
{
private:
    string name;
    int accNo;
    float balance;

public:
    void createAccount()
    {
        cout << "\n===== CREATE ACCOUNT =====\n";
        cout << "Enter Account Holder Name: ";
        cin.ignore();
        getline(cin, name);

        cout << "Enter Account Number: ";
        cin >> accNo;

        cout << "Enter Initial Balance: ";
        cin >> balance;
    }

    void deposit()
    {
        float amount;
        cout << "\nEnter Deposit Amount: ";
        cin >> amount;

        if(amount > 0)
        {
            balance += amount;
            cout << "Amount Deposited Successfully!\n";
        }
        else
        {
            cout << "Invalid Amount!\n";
        }
    }

    void withdraw()
    {
        float amount;
        cout << "\nEnter Withdraw Amount: ";
        cin >> amount;

        if(amount <= balance && amount > 0)
        {
            balance -= amount;
            cout << "Please Collect Your Cash.\n";
        }
        else
        {
            cout << "Insufficient Balance!\n";
        }
    }

    void showAccount()
    {
        cout << "\n===== ACCOUNT DETAILS =====\n";
        cout << "Name           : " << name << endl;
        cout << "Account Number : " << accNo << endl;
        cout << "Balance        : " << balance << endl;
    }
};

int main()
{
    Bank b;
    int choice;

    do
    {
        cout << "\n========== BANKING SYSTEM ==========\n";
        cout << "1. Create Account\n";
        cout << "2. Deposit\n";
        cout << "3. Withdraw\n";
        cout << "4. Account Details\n";
        cout << "5. Exit\n";

        cout << "Enter Choice: ";
        cin >> choice;

        switch(choice)
        {
            case 1:
                b.createAccount();
                break;

            case 2:
                b.deposit();
                break;

            case 3:
                b.withdraw();
                break;

            case 4:
                b.showAccount();
                break;

            case 5:
                cout << "\nThank You!\n";
                break;

            default:
                cout << "\nInvalid Choice!\n";
        }

    } while(choice != 5);

    return 0;
}