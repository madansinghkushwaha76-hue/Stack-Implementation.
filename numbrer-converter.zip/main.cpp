#include <iostream>
using namespace std;

int main()
{
    int choice, decimal, binary[32], i, n;
    char hex[20];

    do
    {
        cout << "\n========== NUMBER CONVERTER ==========\n";
        cout << "1. Decimal to Binary\n";
        cout << "2. Decimal to Hexadecimal\n";
        cout << "3. Exit\n";
        cout << "Enter Choice: ";
        cin >> choice;

        switch(choice)
        {
            case 1:
                cout << "Enter Decimal Number: ";
                cin >> decimal;

                n = decimal;
                i = 0;

                while(n > 0)
                {
                    binary[i] = n % 2;
                    n = n / 2;
                    i++;
                }

                cout << "Binary Number = ";
                for(int j = i - 1; j >= 0; j--)
                    cout << binary[j];

                cout << endl;
                break;

            case 2:
                cout << "Enter Decimal Number: ";
                cin >> decimal;

                sprintf(hex, "%X", decimal);

                cout << "Hexadecimal Number = " << hex << endl;
                break;

            case 3:
                cout << "Thank You!" << endl;
                break;

            default:
                cout << "Invalid Choice!" << endl;
        }

    } while(choice != 3);

    return 0;
}