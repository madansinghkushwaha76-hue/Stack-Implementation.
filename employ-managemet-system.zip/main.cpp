#include <iostream>
using namespace std;

struct Employee
{
    int empId;
    string name;
    float salary;
};

int main()
{
    Employee e[10];
    int n;

    cout << "Enter number of employees: ";
    cin >> n;

    // Input Employee Data
    for(int i = 0; i < n; i++)
    {
        cout << "\nEmployee " << i + 1 << endl;

        cout << "Enter Employee ID: ";
        cin >> e[i].empId;

        cout << "Enter Employee Name: ";
        cin >> e[i].name;

        cout << "Enter Salary: ";
        cin >> e[i].salary;
    }

    // Display Employee Data
    cout << "\n\n----- Employee Records -----\n";

    for(int i = 0; i < n; i++)
    {
        cout << "\nEmployee ID : " << e[i].empId << endl;
        cout << "Name        : " << e[i].name << endl;
        cout << "Salary      : " << e[i].salary << endl;
    }

    return 0;
}